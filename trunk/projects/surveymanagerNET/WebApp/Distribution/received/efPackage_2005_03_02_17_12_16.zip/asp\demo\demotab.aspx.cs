using easyFramework.Sys;
using System;
using easyFramework;
using easyFramework.Frontend.ASP.Dialog;
using easyFramework.Sys.Xml;

namespace easyFramework.Project.Default
{
	//================================================================================
//Class:     demoTab
	
	//--------------------------------------------------------------------------------'
//Module:    demoTab.aspx.vb
	//--------------------------------------------------------------------------------'
//Copyright: Promain Software-Betreuung GmbH, 2004
	//--------------------------------------------------------------------------------'
//Purpose:   Demo-Tab for the entity-edit dialog tabdialog
	//--------------------------------------------------------------------------------'
//Created:   09.05.2004 21:41:06
	//--------------------------------------------------------------------------------'
//Changed:
	//--------------------------------------------------------------------------------'
	
	
	
	
	
	public class demoTab : efDialogPage
	{
		
		#region " Vom Web Form Designer generierter Code "
		
		//Dieser Aufruf ist fr den Web Form-Designer erforderlich.
		[System.Diagnostics.DebuggerStepThrough()]private void InitializeComponent ()
		{
			
		}
		
//HINWEIS: Die folgende Platzhalterdeklaration ist fr den Web Form-Designer erforderlich.
		//Nicht lschen oder verschieben.
		private System.Object designerPlaceholderDeclaration;
		
		private void Page_Init (System.Object sender, System.EventArgs e)
		{
//CODEGEN: Dieser Methodenaufruf ist fr den Web Form-Designer erforderlich
			//Verwenden Sie nicht den Code-Editor zur Bearbeitung.
			InitializeComponent();
		}
		
		#endregion
		
		
		private void Page_Load (XmlDocument oXmlRequest)
		{
			
		}
	}
	
}

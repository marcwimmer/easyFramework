INSERT INTO [tsIcons]([icon_id], [icon_relativepath], [icon_filename], [icon_width], [icon_height])
VALUES('icon_arrow_scrollDown_yellow', '/ASP/images', 'icon_arrow_scrollDown_yellow.gif',16,16)
GO
INSERT INTO [tsIcons]([icon_id], [icon_relativepath], [icon_filename], [icon_width], [icon_height])
VALUES('icon_arrow_scrollUp_yellow', '/ASP/images/', 'icon_arrow_scrollUp_yellow.gif',16,16)
GO


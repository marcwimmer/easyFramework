/* (c) Promain Software-Betreuung GmbH 2004 */

//the following function is used to set-up the treeview:
function loadTreeView(sDivID, sDataPage, sServerParams, 
	sImage_I, sImage_R, sImage_L, sImage_LMinus, 
	sImage_LPlus, sImage_T, sImage_TMinus, sImage_TPlus, 
	sImage_Clear, lNodeHeight) {
	
	var sData = gsCallServerMethod(sDataPage, sServerParams);
	
	lNodeHeight = lNodeHeight;
	sTreeNodeImage_IGif = sImage_I;
	sTreeNodeImage_clear = sImage_Clear;
	sTreeNodeImage_LGif = sImage_L;
	sTreeNodeImage_LMinusGif = sImage_LMinus;
	sTreeNodeImage_LPlusGif = sImage_LPlus;
	sTreeNodeImage_rGif = sImage_R;
	sTreeNodeImage_tGif = sImage_T;
	sTreeNodeImage_tMinusGif = sImage_TMinus;
	sTreeNodeImage_tPlusGif = sImage_TPlus;
	
	dataToTreeview(sData, sDivID, lNodeHeight)
	
	
}

//this function converts tereview-structure information to the treeview-nodes:
function dataToTreeview(sData, sDivID, lNodeHeight) {
	//renders the given-data to a treeview:
	
	var sLineEnd = new String("-||-")
	var sColumnSep = new String("|")
	
	var sLocalData = new String(sData);
	//just do char 13 instead of 13 + 10:
	sLocalData=sLocalData.replace(String.fromCharCode(13), "");
	sLocalData=sLocalData.replace(String.fromCharCode(10), "");
	
	//check for OK:
	if (sLocalData.substring(0, 6) != "OK-||-") {
		efMsgBox(sLocalData, "ERROR");
		return
	} else {
		sLocalData = sLocalData.substring(6);
	}
	
	while (sLocalData.indexOf(sLineEnd) >= 0) {
		var sLine = new String(sLocalData.substr(0, sLocalData.indexOf(sLineEnd)));
		sLocalData = sLocalData.substring(sLocalData.indexOf(sLineEnd) + 
			sLineEnd.length, sLocalData.length);
		
		var bMainItem = false;
		var sParentID;
		var sID;
		var sCaption;
		var sCommand;
		var sIconNormal;
		var sIconOpened;
		var bIsFolder;
		
		//first column is parent-id:
		sParentID = sLine.substr(0, sLine.indexOf(sColumnSep));
		if (sParentID == "NULL" || sParentID == "null")		{
			sParentID = "";
			bMainItem = true;
		} else bMainItem = false;
		sLine = sLine.substring(sLine.indexOf(sColumnSep) + 1, sLine.length);
		
		//second column is id:
		sID = sLine.substr(0, sLine.indexOf(sColumnSep));
		sLine = sLine.substring(sLine.indexOf(sColumnSep) + 1, sLine.length);
		
		//third column is caption:
		sCaption = sLine.substr(0, sLine.indexOf(sColumnSep));
		sLine = sLine.substring(sLine.indexOf(sColumnSep) + 1, sLine.length);
		
		//fourth column is command:
		sCommand = sLine.substr(0, sLine.indexOf(sColumnSep));
		sLine = sLine.substring(sLine.indexOf(sColumnSep) + 1, sLine.length);
		
		//fifth column is bool - folder:
		bIsFolder = !(sLine.substr(0, sLine.indexOf(sColumnSep)) == "0");
		sLine = sLine.substring(sLine.indexOf(sColumnSep) + 1, sLine.length);
		
		//sixth column is image normal
		sIconNormal = sLine.substr(0, sLine.indexOf(sColumnSep));
		sLine = sLine.substring(sLine.indexOf(sColumnSep) + 1, sLine.length);
		
		//seventh column is image opened
		sIconOpened = sLine.substr(0, sLine.indexOf(sColumnSep));
		sLine = sLine.substring(sLine.indexOf(sColumnSep) + 1, sLine.length);
		
		
		//create node:
		if (bMainItem == true) 
			createMainNode(sDivID, sID, sCaption, sCommand, bIsFolder, sIconOpened, sIconNormal);
		else
			appendNode(sParentID, sID, sCaption, sCommand, bIsFolder, sIconOpened, sIconNormal);
	
		
	}
	
	renderNodes();
}


//images, set by function   loadTreeView
	var sTreeNodeImage_IGif = "/easyFramework/ASP/images/treeview/I.gif"
	var sTreeNodeImage_rGif = "/easyFramework/ASP/images/treeview/r.gif"
	var sTreeNodeImage_LGif = "/easyFramework/ASP/images/treeview/L.gif"
	var sTreeNodeImage_LMinusGif = "/easyFramework/ASP/images/treeview/LMinus.gif"
	var sTreeNodeImage_LPlusGif = "/easyFramework/ASP/images/treeview/LPlus.gif"
	var sTreeNodeImage_tGif = "/easyFramework/ASP/images/treeview/t.gif"
	var sTreeNodeImage_tMinusGif = "/easyFramework/ASP/images/treeview/tMinus.gif"
	var sTreeNodeImage_tPlusGif = "/easyFramework/ASP/images/treeview/tPlus.gif"
	var sTreeNodeImage_clear = "/easyFramework/ASP/images/treeview/clear.gif"



//functions for generating a treeview:

	//variables
	var aoAllMainNodes = new Array(0);	
	var aoAllNodes = new Array(0);	
	var praefix = "treenode_";
	var lNodeHeight = 20;
	
	//folder-object:
	function Node(sId, sText, sCommand, oParentNode, oContainer, bIsFolder,
		sOpenImage, sClosedImage) { //constructor
								 
		//methods private:
		this.render = nodeRender;
		this.getLevel = nodeGetLevels;
		this.getHeight = nodeLGetHeight;
		this.getPrecedingNodes = nodeGetPrecedingNodes;
		this.getSuccessingNodes = nodeGetSuccessingNodes;
		this.getShallTop = nodeGetShallTop;
		this.areThereSuccessors = nodeAreThereSuccessors;
		this.getParentByLevel = nodeGetParentByLevel;
		this.isAnyParentNotOpened = nodeIsAnyParentNotOpened;
		this.getVisibility = nodeGetVisibility;
		this.sCommand = sCommand;
		
		//methods public:
		
		//properties
		this.bIsFolder = bIsFolder;
		this.bIsOpened = false;
		this.id = praefix + sId;
		this.oParentNode = oParentNode;
		this.oContainer = oContainer; // the div of the node
		this.sText = sText;
		this.sOpenImage = sOpenImage;
		this.sClosedImage = sClosedImage;
		this.children = new Array;
		
		
		//the belonging div-element:
		this.oDiv = document.createElement("div");
		this.oDiv.style.position = "absolute";
		this.oDiv.style.top = 30;
		this.oDiv.style.left = 0;
		this.oDiv.style.height = lNodeHeight + 2;
		this.oContainer.appendChild(this.oDiv);
		
		return this;
	}
	
	function nodeGetLevels() {
	
		if (this.oParentNode == null) 
			return 1;
		else
			return this.oParentNode.getLevel() + 1;
	}
	
	function nodeRender() {
	    
	    var trPraefix = "treenodeRow_";
	    
	    var bShowItems;
	    if (this.oParentNode != null)	
			bShowItems = !this.isAnyParentNotOpened();
		else bShowItems = true;
		
		var sInnerHtml = "";
		
		if (bShowItems==false)	{
		
		}
		else
		{
	    
			sInnerHtml = "<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\">" +
				"<tr style=\"cursor: pointer; cursor:hand\" id=\""+this.id+"\" onclick=\"onNodeClick(this.id);\">";
				
		    
			var lLevel = this.getLevel();
			for (i = 0; i < lLevel - 1; i++) {
		    
				var oParentByLevel = this.getParentByLevel(i + 1);
				if (oParentByLevel != null) {
					if (oParentByLevel.areThereSuccessors() == true) 
						sInnerHtml += "<td width=\"1\" align=\"left\" valign=\"top\" class=\"dlgField\"><img src=\""+sTreeNodeImage_IGif+"\"></td>"; 
					else
						sInnerHtml += "<td width=\"1\" align=\"left\" valign=\"top\"  class=\"dlgField\"><img src=\""+sTreeNodeImage_clear+"\"></td>"; 
				}
			}
		    
			if (lLevel >= 2) {
				sInnerHtml += "<td width=\"1\"  align=\"left\" valign=\"top\" class=\"dlgField\"><img src=\"";
				
				
				//decide wether to take the L or t -element:
				var bTakeT = true; //if not t-element, then the L-element
				
				//when to take the t-element? if there is at least on successor, then
				//take the t, else the l:
				if (this.areThereSuccessors() == true) 
					bTakeT = true;
				else
					bTakeT = false;
				
				
				if (this.bIsFolder == true) {
					if (this.bIsOpened == true) {
						if (bTakeT == true) {
							sInnerHtml += sTreeNodeImage_tMinusGif;
						}
						else sInnerHtml += sTreeNodeImage_LMinusGif;
					}
					else {
						if (bTakeT == true) {
							sInnerHtml += sTreeNodeImage_tPlusGif;
						}
						else sInnerHtml += sTreeNodeImage_LPlusGif;
					}
				}
				else {
					if (bTakeT == true)
						sInnerHtml += sTreeNodeImage_tGif;
					else
						sInnerHtml += sTreeNodeImage_LGif;
					
				}
				
				sInnerHtml += "\"></td>"; 
			}
		    
			//icon:
			var sImageIcon;
			if (this.bIsOpened) 
				sImageIcon = this.sOpenImage; 
			else sImageIcon = this.sClosedImage;
				
			sInnerHtml += "<td class=\"dlgField\"><img src=\""+
				sImageIcon+"\"></td>"
			
			//text:		
			sInnerHtml += "<td nowrap=\"true\" class=\"dlgField\">"+this.sText+"</td>"; 
		
			sInnerHtml += "</td></tr></table>"; 
		    
		}
		sInnerHtml += "<td nowrap=\"true\" class=\"dlgField\">";
		//setting the top-value:
		this.oDiv.style.top = this.getShallTop() - lNodeHeight;  
		
		
		//display the html:															 
		sInnerHtml = sInnerHtml.replace("'", "''");
		window.setTimeout("oGetNode('"+this.id+"').oDiv.innerHTML = '"+sInnerHtml+"'", 0);
		
		//render the children:
		var i = 0;
		
		if (this.children.length > 0) 
			for (i = 0; i < this.children.length; i++) {
				this.children[i].render();
		}		   
	}
	
	function nodeIsAnyParentNotOpened() {
		//returns true, if there is any parent, that is not opened:
	
	
		if (this.oParentNode != null) {
			if (this.oParentNode.bIsOpened == false) 
				return true;
			else
				return this.oParentNode.isAnyParentNotOpened();
		}
		else {
			if (this.bIsOpened == false) 
				return true;
			else
				return false;
		}
	}
	
	function nodeGetParentByLevel(lLevel) {
		//retrieves the parent-node by the given level:
		if (this.getLevel() == lLevel) {
			return this;
		}
		else {
			if (this.oParentNode != null) {
				return this.oParentNode.getParentByLevel(lLevel);
			}
		}
	}
	
	function nodeGetShallTop() {
		//returns the top-value, this element SHOULD have:
		
		var aoGetPrecedingNodes = this.getPrecedingNodes();
	    var lTop = 0;
	    if (this.oParentNode != null) { 
			lTop = this.oParentNode.getShallTop() 
			
		}
			
		for (i = 0; i < aoGetPrecedingNodes.length; i++) {
			lTop += aoGetPrecedingNodes[i].getHeight();
		}	
		
		lTop += lNodeHeight;
		
		
		return lTop;
	  
	}
	
	function nodeGetPrecedingNodes() {
		//returns all preceding nodes of a node:
		var oParent = this.oParentNode;
		if (oParent == null) { //we are a top-element; the preceding elements are the other top-elements before
			var result = new Array();
			for (i = 0; i < aoAllMainNodes.length; i++) {
				if (aoAllMainNodes[i].id != this.id) {
					result.push(aoAllMainNodes[i]);
				}
				else break;
			}
			
			return result;
		}
		else { //we are a sub-element; go to the parent and get all preceding children:
			var result = new Array();
			for (i = 0; i < oParent.children.length; i++) {
				if (oParent.children[i].id != this.id) {
					result.push(oParent.children[i]);
				}
				else break;
			}
			return result;
		
		}	
	
	}
	
	function nodeGetSuccessingNodes() {
		//returns all successing nodes of a node:
		var oParent = this.oParentNode;
		if (oParent == null) { //we are a top-element; the preceding elements are the other top-elements before
			var result = new Array();
			var bPassedMySelf = false;
				
			for (i = 0; i < aoAllMainNodes.length; i++) {
				
				if (bPassedMySelf == true)
					result.push(aoAllMainNodes[i]);

				if (aoAllMainNodes[i].id == this.id) 
					bPassedMySelf = true;
					
			}
			
			return result;
		}
		else { //we are a sub-element; go to the parent and get all preceding children:
			var result = new Array();
			var bPassedMySelf = false;
			
			for (i = 0; i < oParent.children.length; i++) {


				if (bPassedMySelf == true)
					result.push(oParent.children[i]);

				if (oParent.children[i].id == this.id) 
					bPassedMySelf = true;


				
			}
			return result;
		
		}	
	
	}
	
	function nodeAreThereSuccessors() {
	
		//return bool, if there are successing elements:
		var oParent = this.oParentNode;
		if (oParent == null) { //we are a top-element; the preceding elements are the other top-elements before
			var result = new Array();
			for (i = 0; i < aoAllMainNodes.length; i++) {
				if (aoAllMainNodes[i].id == this.id) {
					if (i < aoAllMainNodes.length - 1) 
						return true;
					else
						return false;
				}
			}
			
			return false;
		}
		else { //we are a sub-element; go to the parent and get all preceding children:
			var result = new Array();
			for (i = 0; i < oParent.children.length; i++) {
				if (oParent.children[i].id == this.id) {
					if (i < oParent.children.length - 1) 
						return true;
					else	{
						return false;		    
					}
				}
			}
			return false;
		
		}	

	}
	
	function nodeGetVisibility() {
		//determines, wether the current node should be visible or not
		
		if (this.isAnyParentNotOpened() == true) 
			return false;
			
	}
	
	function nodeLGetHeight() {
		//liefert die H�he des Elements inklusive der Children zur�ck:
		
		if (this.bIsOpened == false) 
			return lNodeHeight;
		
		var lHeight = lNodeHeight;
		var i = 0;
		for (i = 0; i < this.children.length; i++) {
			lHeight += this.children[i].getHeight();
			
		}
		
		return lHeight;
	
	}
	
	
	function createMainNode(sParentDiv, sId, sText, sCommand, bIsFolder, sOpenImage, sClosedImage) {
		if (oGetNode(sId, false) != null) {
			alert("element with id " + sId + " already exists!");
			return
		}

		var n = new Node(sId, sText, sCommand, null, document.getElementById(sParentDiv), bIsFolder, sOpenImage, sClosedImage)
		//add into main-nodes:
		aoAllMainNodes.push(n);
		aoAllNodes.push(n);
		
		return n;
	}
	
	function appendNode(sParentId, sId, sText, sCommand, bIsFolder, sOpenImage, sClosedImage) {
	
		if (oGetNode(sId,false) != null) {
			alert("element with id " + sId + " already exists!");
			return
		}
	
		var oParentNode = oGetNode(sParentId);
		var n = new Node(sId, sText, sCommand, oParentNode, oParentNode.oContainer, bIsFolder, sOpenImage, sClosedImage)
		
		//add to children list:
		aoAllNodes.push(n);
		oParentNode.children.push(n);
		
		return n;
	}
	
	function oGetNode(sId, bErrorIfNotFound) {
		//returns a node from the node-element-array
	
		var i;
		var sLocalID = String(sId);
		if (sLocalID.substring(0, praefix.length) != praefix) 
			sLocalID = praefix + sLocalID;
		for (i = 0; i < aoAllNodes.length; i++) {
			if (aoAllNodes[i].id == sLocalID) {
			
				return aoAllNodes[i]
			}
		}
		if (bErrorIfNotFound != false) 
			alert("error getting node: " + sId);
	}
	
	function renderNodes() {
	
		var i = 0;
		for (i=0; i < aoAllMainNodes.length; i++) {
		
			aoAllMainNodes[i].render();
		
		}
	
	}
	
	function onNodeClick(id) {
	
		var oNode = oGetNode(id);
		oNode.bIsOpened = !oGetNode(id).bIsOpened;
		
		//optimization: do not render all nodes; just the current node,
		//all children and all the nodes, which lie on the screen UNDER
		//the current node:
		
		oNode.render();
		var i=0;
		for (i=oNode.getLevel(); i >= 1; i--) {
			var underlieingNode = oNode.getParentByLevel(i);
			var oSuccessors = underlieingNode.getSuccessingNodes();
			
			for (y=0; y < oSuccessors.length; y++) {
				oSuccessors[y].render();
				
			}
		}		
		
		
		if (oNode.sCommand != "") {
			eval(oNode.sCommand);
		
		}
		
	}
	
	
	function gMakeNodeVisible(sNodeId) {
		//searches the nodes to find the given id; then all upper nodes are expanded, so that
		//this node is visible
	
		var oNode = oGetNode(sNodeId);
		
		
		mExpandParentNode(oNode);
		
		renderNodes();
	
	}
	
	function mExpandParentNode(oCurrentNode) {
	
		oCurrentNode.bIsOpened = true;
		
		if (oCurrentNode.oParentNode != null) {
			mExpandParentNode(oCurrentNode.oParentNode);
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
UPDATE tsUsers
SET usr_password = 'easy'
WHERE usr_login = 'sa'

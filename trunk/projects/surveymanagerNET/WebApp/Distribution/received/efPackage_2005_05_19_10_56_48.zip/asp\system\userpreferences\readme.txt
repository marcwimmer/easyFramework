in der user-preferences seite, soll der benutzer folgende einstellungen vornehmen k�nnen:

- erweiterten HTML-Editor nutzen (usr_not_extendedHtmlEditor)
...
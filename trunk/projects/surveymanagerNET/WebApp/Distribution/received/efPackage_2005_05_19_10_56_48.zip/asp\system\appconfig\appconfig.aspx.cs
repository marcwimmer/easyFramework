using easyFramework.Sys;
using System;
using easyFramework;

namespace easyFramework.Project.Default
{
	public class AppConfig : System.Web.UI.Page
	{
		
		#region " Vom Web Form Designer generierter Code "
		
		//Dieser Aufruf ist fr den Web Form-Designer erforderlich.
		[System.Diagnostics.DebuggerStepThrough()]private void InitializeComponent ()
		{
			
		}
		protected easyFramework.Frontend.ASP.WebComponents.efPageHeader EfPageHeader1;
		protected easyFramework.Frontend.ASP.WebComponents.efScriptLinks EfScriptLinks1;
		protected easyFramework.Frontend.ASP.WebComponents.efPageHeader Efpageheader2;
		protected easyFramework.Frontend.ASP.WebComponents.efScriptLinks Efscriptlinks2;
		
//HINWEIS: Die folgende Platzhalterdeklaration ist fr den Web Form-Designer erforderlich.
		//Nicht lschen oder verschieben.
		private System.Object designerPlaceholderDeclaration;
		
		private void Page_Init (System.Object sender, System.EventArgs e)
		{
//CODEGEN: Dieser Methodenaufruf ist fr den Web Form-Designer erforderlich
			//Verwenden Sie nicht den Code-Editor zur Bearbeitung.
			InitializeComponent();
		}
		
		#endregion
		
		private void Page_Load (System.Object sender, System.EventArgs e)
		{
			// Hier Benutzercode zur Seiteninitialisierung einfgen
		}
		
	}
	
}

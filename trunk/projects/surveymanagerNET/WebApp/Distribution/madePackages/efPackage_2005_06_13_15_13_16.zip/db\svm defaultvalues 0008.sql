
INSERT INTO [tsIcons]([icon_id], [icon_relativepath], [icon_filename], [icon_width], [icon_height])
VALUES('treeview_question', '/ASP/project/surveymanager/images/', 'question.gif',20,20)
GO
INSERT INTO [tsIcons]([icon_id], [icon_relativepath], [icon_filename], [icon_width], [icon_height])
VALUES('treeview_answer', '/ASP/project/surveymanager/images/', 'answer.gif',20,20)
GO
INSERT INTO [tsIcons]([icon_id], [icon_relativepath], [icon_filename], [icon_width], [icon_height])
VALUES('treeview_answervalue', '/ASP/project/surveymanager/images/', 'answervalue.gif',20,20)
GO
INSERT INTO [tsIcons]([icon_id], [icon_relativepath], [icon_filename], [icon_width], [icon_height])
VALUES('treeview_correct', '/ASP/project/surveymanager/images/', 'correct.gif',20,20)
GO
INSERT INTO [tsIcons]([icon_id], [icon_relativepath], [icon_filename], [icon_width], [icon_height])
VALUES('treeview_wrong', '/ASP/project/surveymanager/images/', 'wrong.gif',20,20)

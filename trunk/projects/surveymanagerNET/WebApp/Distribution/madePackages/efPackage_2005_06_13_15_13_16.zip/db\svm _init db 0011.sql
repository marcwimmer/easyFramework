ALTER TABLE tdAnswerValues
ADD val_text_on_correct NVARCHAR(512), val_text_on_false NVARCHAR(512)


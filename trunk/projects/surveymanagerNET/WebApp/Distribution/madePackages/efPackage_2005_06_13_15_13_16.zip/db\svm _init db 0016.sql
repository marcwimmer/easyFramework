alter table tdQuestions
add qst_mathml NVARCHAR(4000) NULL
alter table tdSurveys
add svy_zufallsfragen_poolgroesse int NULL
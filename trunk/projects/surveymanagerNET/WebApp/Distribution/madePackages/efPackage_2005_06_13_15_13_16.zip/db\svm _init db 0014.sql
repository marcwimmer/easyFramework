alter table tdAnswerTypes
add aty_xmldialog_path nvarchar(255)
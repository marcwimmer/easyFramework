INSERT INTO tdAnswertypes(aty_id, aty_name)
VALUES('CHECKBOX', 'Checkbox')
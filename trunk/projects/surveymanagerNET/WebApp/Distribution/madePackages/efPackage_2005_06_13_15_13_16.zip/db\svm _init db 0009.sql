ALTER TABLE tdQuestions
ADD qst_layout_description_on_the_left INT

alter table tdAnswerValues
add val_mathml NVARCHAR(4000) NULL
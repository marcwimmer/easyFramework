ALTER TABLE tdAnswers
ADD ans_html_before NVARCHAR(255), ans_html_after NVARCHAR(255)
